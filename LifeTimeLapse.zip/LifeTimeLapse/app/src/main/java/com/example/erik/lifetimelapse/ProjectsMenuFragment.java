package com.example.erik.lifetimelapse;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.ListView;

import com.example.erik.lifetimelapse.models.Project;
import com.example.erik.lifetimelapse.utils.ProjectsMenuCVAdapter;

import java.util.ArrayList;
import de.hdodenhof.circleimageview.CircleImageView;
/**
 * Created by Erik on 1/17/2018.
 */

public class ProjectsMenuFragment extends Fragment{

    private static final String TAG = "ProjectsMenuFragment";

    //Variables and Widgets
    private static final int STANDARD_APPBAR = 1;
    private static final int SEARCH_APPBAR = 0;
    private int mAppBarState;

    private AppBarLayout viewProjectsMenuBar, searchBar;
    private ProjectsMenuCVAdapter adapter;
    private ListView projectsList;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_projectsmenu, container, false);
        viewProjectsMenuBar = (AppBarLayout) view.findViewById(R.id.viewProjectsMenuToolbar);
        searchBar = (AppBarLayout) view.findViewById(R.id.searchToolbar);
        projectsList = (ListView) view.findViewById(R.id.lvProjectsList);

        Log.d(TAG, "onCreateView: started");

        setAppBarState(STANDARD_APPBAR);
        setupProjectsList();

        //Pop Welcome from Backstack
        FragmentManager manager = getActivity().getSupportFragmentManager();
        manager.popBackStack("WelcomeOneFragment",FragmentManager.POP_BACK_STACK_INCLUSIVE);

        //Tool Bar Toggle Functionality - Identifying the Buttons
        //and activating toggleToolBarState method
        ImageView ivSearchProject = (ImageView) view.findViewById(R.id.ivSearchIcon);
        ivSearchProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: clicked search icon");
                toggleToolBarState();
            }
        });
        ImageView ivBackArrow = (ImageView) view.findViewById(R.id.ivBackArrow);
        ivBackArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: clicked back arrow.");
                toggleToolBarState();
            }
        });

        return view;
    }

    private void setupProjectsList() {
        final ArrayList<Project> projects = new ArrayList<>();
        projects.add(new Project("Project 1", "Errday","100 days","365 days","Tag1"));
        projects.add(new Project("Project 2", "Errweek","2 weeks","10 weeks","Tag2"));
        projects.add(new Project("Project 3", "Errday","1 day","365 days","Tag3"));
        projects.add(new Project("Project 4", "Errday","100 days","365 days","Tag1"));
        projects.add(new Project("Project 5", "Errweek","2 weeks","10 weeks","Tag2"));
        projects.add(new Project("Project 6", "Errday","1 day","365 days","Tag3"));
        projects.add(new Project("Project 7", "Errday","100 days","365 days","Tag1"));
        projects.add(new Project("Project 8", "Errweek","2 weeks","10 weeks","Tag2"));
        projects.add(new Project("Project 9", "Errday","1 day","365 days","Tag3"));
        projects.add(new Project("Project 10", "Errday","100 days","365 days","Tag1"));
        projects.add(new Project("Project 11", "Errweek","2 weeks","10 weeks","Tag2"));
        projects.add(new Project("Project 12", "Errday","1 day","365 days","Tag3"));
        ProjectsMenuCVAdapter adapter = new ProjectsMenuCVAdapter(getActivity(),R.layout.layout_projectscardview, projects, null);
        projectsList.setAdapter(adapter);
    }

    //initiates appbar state toggle
    private void toggleToolBarState() {
        Log.d(TAG, "toggleToolBarState: toggling AppBarState");
        if(mAppBarState == STANDARD_APPBAR) {
            setAppBarState(SEARCH_APPBAR);
        }
        else {
            setAppBarState(STANDARD_APPBAR);
        }
    }

    //Sets Appbar state for either search mode or standard mode
    private void setAppBarState(int state) {
        Log.d(TAG, "setAppBarState: changing app bar state to " + state);
        mAppBarState = state;
        if(mAppBarState == SEARCH_APPBAR) {
            viewProjectsMenuBar.setVisibility(View.GONE);
            searchBar.setVisibility(View.VISIBLE);
            //Open Keyboard
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,0);
        }
        else if (mAppBarState == STANDARD_APPBAR) {
            searchBar.setVisibility(View.GONE);
            viewProjectsMenuBar.setVisibility(View.VISIBLE);
            View view = getView();
            //Close Keyboard
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            try{
                imm.hideSoftInputFromWindow(view.getWindowToken(),0);
            }catch (NullPointerException e){
                Log.d(TAG, "setAppBarState: NullPointerException: " + e.getMessage());
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        setAppBarState(STANDARD_APPBAR);
    }
}
