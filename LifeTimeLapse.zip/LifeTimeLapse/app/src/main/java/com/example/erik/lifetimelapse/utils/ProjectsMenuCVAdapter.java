package com.example.erik.lifetimelapse.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.erik.lifetimelapse.R;
import com.example.erik.lifetimelapse.models.Project;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Erik on 1/16/2018.
 */

public class ProjectsMenuCVAdapter extends ArrayAdapter<Project> {
    private LayoutInflater mInflater;
    private List<Project> mProjects = null;
    private ArrayList<Project> arrayList; //used for search bar
    private int layoutResource;
    private Context mContext;
    private String mAppend;

    public ProjectsMenuCVAdapter(@NonNull Context context, int resource, @NonNull List<Project> projects, String append) {
        super(context, resource, projects);
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        layoutResource = resource;
        this.mContext = context;
        mAppend = append;
        this.mProjects = projects;
        arrayList = new ArrayList<>();
        this.arrayList.addAll(mProjects);
    }

    private static class ViewHolder{
        //Stuff to change if using this as template ******************
        ImageView firstPic;
        ImageView lastPic;
        TextView projectName;
        //ProgressBar mProgressBar;
        //*******************************************************************
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        //ViewHolder Build Pattern Start ******************
        final ViewHolder holder;

        if(convertView == null){
            convertView = mInflater.inflate(layoutResource, parent, false);
            holder = new ViewHolder();

            //************************************Stuff to Change if using this as template******
            holder.projectName = (TextView)convertView.findViewById(R.id.cvProjectName);
            holder.firstPic = (ImageView) convertView.findViewById(R.id.projectImage1);
            holder.lastPic = (ImageView) convertView.findViewById(R.id.projectImage2);
            //holder.mProgressBar = (ProgressBar) convertView.findViewById(R.id.projectProgressBar);
            //***********************************************************************

            convertView.setTag(holder);
        }
        else{
            holder = (ViewHolder) convertView.getTag();
        }

        //************************************Stuff to Change if using this as template******
        String projects = getItem(position).getProjName();
        holder.projectName.setText(projects);
        holder.lastPic.setImageResource(mContext.getResources().getIdentifier("drawable/ic_smile", null, mContext.getPackageName()));
        holder.firstPic.setImageResource(mContext.getResources().getIdentifier("drawable/ic_face", null, mContext.getPackageName()));
        //*****************************************************************************

        return convertView;
    }
}

