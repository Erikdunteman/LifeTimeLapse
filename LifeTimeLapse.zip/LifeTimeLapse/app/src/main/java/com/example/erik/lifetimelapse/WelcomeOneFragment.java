package com.example.erik.lifetimelapse;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.support.v7.app.AppCompatActivity;
import android.widget.RelativeLayout;

/**
 * Created by Erik on 1/19/2018.
 */

public class WelcomeOneFragment extends Fragment {
    private static final String TAG = "WelcomeOneFragment";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_welcome, container, false);
        Log.d(TAG, "onCreateView: Welcome Screen 1 Opened");

        RelativeLayout screen = (RelativeLayout) view.findViewById(R.id.welcomeScreen);
        screen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: Welcome Screen Clicked");
                init_f_pm();
            }
        });

        return view;
    }

    //initialize the first fragment (ProjectsMenuFragment)
    public void init_f_pm(){
        ProjectsMenuFragment fragment = new ProjectsMenuFragment();
        android.support.v4.app.FragmentTransaction transaction = getFragmentManager().beginTransaction();
        // replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.fragment_container, fragment);
        transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        transaction.commit();
    }
}
